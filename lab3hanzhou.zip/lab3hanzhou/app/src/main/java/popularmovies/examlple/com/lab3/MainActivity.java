package popularmovies.examlple.com.lab3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private Button button;
    private EditText textView25;
    private EditText textView10;
    private EditText textView5;
    private EditText textView1;

    private int num25=0;
    private int num10=0;
    private int num5=0;
    private int num1=0;

    private String selection;

    private double total;

    DecimalFormat currencyFormat = new DecimalFormat("$###,###.##");

    private String output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        spinner = findViewById(R.id.spinner);
        textView25 = findViewById(R.id.editText_25);
        textView10 = findViewById(R.id.editText_10);
        textView5 = findViewById(R.id.editText_5);
        textView1 = findViewById(R.id.editText_1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                selection = spinner.getSelectedItem().toString();

                try{
                    if(textView25.getText().toString().isEmpty() == false)
                    {
                        total += Integer.parseInt(textView25.getText().toString())*.25;
                    }
                    if(textView10.getText().toString().isEmpty() == false)
                    {
                        total += Integer.parseInt(textView25.getText().toString())*.1;
                    }
                    if(textView5.getText().toString().isEmpty() == false)
                    {
                        total += Integer.parseInt(textView25.getText().toString())*.05;
                    }
                    if(textView1.getText().toString().isEmpty() == false)
                    {
                        total += Integer.parseInt(textView25.getText().toString())*.01;
                    }

                    if(selection.equals("save"))
                    {
                         output ="Total amount saved is "+currencyFormat.format(total);

                    }else if (selection.equals("spend"))
                    {
                           output ="Total amount spend is "+currencyFormat.format(total);

                    }
                    Intent i = new Intent(MainActivity.this, SecondActivity.class);
                    i.putExtra("d1",output);
                    startActivity(i);

                }catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, "Unexpected error", Toast.LENGTH_LONG).show();
                }






            }
        });

    }
}
